import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BaseComponent } from './base.component';

const routes: Routes = [
  {
    path: '', component: BaseComponent,
    children: [
      { path: '', redirectTo: 'index' },
      { path: 'index', loadChildren: './index/index.module#IndexModule' },
      { path: 'who-we-are', loadChildren: './about/about.module#AboutModule', data : {some_data : 'some value'} },
      { path: 'what-we-do', loadChildren: './services/services.module#ServicesModule' },
      { path: 'contact', loadChildren: './contact/contact.module#ContactModule' },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BaseRoutingModule {
}
