import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BaseComponent } from './base.component';
import { BaseRoutingModule } from './base-routing.module';
import { HeaderComponent } from './shared/layout/header/header.component';
import { FooterComponent } from './shared/layout/footer/footer.component';

import { EstimateService } from './shared/services/estimate.service';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';



@NgModule({
  imports: [
    CommonModule, BaseRoutingModule, NgbModule
  ],
  declarations: [BaseComponent,  HeaderComponent, FooterComponent],
  providers: [EstimateService]
})
export class BaseModule { }
