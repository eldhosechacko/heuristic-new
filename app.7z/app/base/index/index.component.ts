import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';

import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { routerTransition } from '../../router.animations';

@Component({
    selector: 'app-estimate',
    templateUrl: './index.component.html',
    encapsulation: ViewEncapsulation.None,
    styleUrls: ['./index.component.css'],
    animations: [routerTransition()]
})
export class IndexComponent implements OnInit {


    constructor() {}

    ngOnInit() {
        console.log('in index');
    }

}
