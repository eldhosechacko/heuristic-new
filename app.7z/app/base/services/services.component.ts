import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../router.animations';
import { BsDropdownModule } from 'ngx-bootstrap';

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.css'],
  animations: [routerTransition()]
})
export class ServicesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
