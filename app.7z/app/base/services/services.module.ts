import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ServicesRoutingModule } from './services-routing.module';
import { ServicesComponent } from './services.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { BsDropdownModule, TabsModule } from 'ngx-bootstrap';

@NgModule({
  imports: [CommonModule, ServicesRoutingModule,  NgbModule, TabsModule, BsDropdownModule.forRoot()],
  declarations: [ServicesComponent]
})
export class ServicesModule { }
