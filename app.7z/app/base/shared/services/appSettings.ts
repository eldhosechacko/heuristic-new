﻿export class AppSettings {
  //public static apiUrl = '/api'; //production
  public static apiUrl = 'http://localhost:5000/api/'; //local development
  //public static apiUrl:string='/ECAPI/api'; //UAT
  //public static apiUrl:string='https://m.np.ustdigitalqa.ust-global.com/api'; //QA


}
