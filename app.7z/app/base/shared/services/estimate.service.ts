import { Injectable } from '@angular/core';
import { HttpService } from './http.service';
import { AppSettings } from './appSettings';

@Injectable()
export class EstimateService {

    private readUrl: string = AppSettings.apiUrl + 'estimates/read-estimate-detail';
    private writeUrl: string = AppSettings.apiUrl + 'estimates/write-estimate-detail';

    constructor(private http: HttpService) { }

    /*Read from service */
    readEstimateDetail(identifier) {
        const data = {"identifier": identifier};
        return this.http.post(this.readUrl, data).map((res) => {
            return res.json();
        });
    }

    /*write to service */
    writeEstimateDetail(estimateData) {console.log(estimateData);
        return this.http.post(this.writeUrl, estimateData).map((res) => {
            return res.json();
        });
    }




}
